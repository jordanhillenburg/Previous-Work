import java.util.Scanner;
public class PalindromeCheck{
	public static void main(String[]args){
		Scanner scan = new Scanner(System.in);
    	CharStack stack = new CharStack();
		
		System.out.println("Input a word to check: ");
		String string1 = scan.nextLine();//string to compare with
		
		for(int i=0;i<string1.length();i++){//push string onto stack
			char current = string1.charAt(i);
			stack.push(current);
		}
		String string2 = "";
		while(!stack.isEmpty()){
			
			string2 = string2 + stack.pop();

		}
		String upper1 = string1.toUpperCase();
		String upper2 = string2.toUpperCase();
		if(upper1.equals(upper2)){
			System.out.print("This word is a palindrome.");
		}
		else{
			System.out.print("This word is not a palindrome.");
		}
	}
}

public class CharStack
{
  private final int MAX_CAP = 100;
  private int top; //location of top item on the stack
  private char [] s; //The stack

  public CharStack(){
    //PRE: none
    //POS: top == -1. not empty
    //TAS: Create an empty stack with a default capacity
    s = new char[MAX_CAP];
    top = -1;
  }

  public void push(char element){
    //PRE: stack is not empty and not full
    //POS: top incremented. s[top] contains newest element
    //TAS: Add a new item to the stack
    top ++;
    s[top] = element;
  }
  
  public void reset(){
    while(!isEmpty){
      pop();
    }
  }

  public char pop (){
    //PRE: stack is not empty
    //POS:stack is one element shorter. Top is one less
    //TAS: remove and return the item on the top of the stack
    char result = s[top];
    top--;
    return result;
    
    
  }
  public char peek(){
    //PRE: stack is not empty 
    //POS: none 
    //TAS: return value at top
    return s[top];
  }
  public boolean isEmpty(){
    if(top == -1)
      return true;
    else
      return false;
}
  public String toString(){
    String result = "";
    for(int i=0;i<top+1;i++){
      result += s[i] + " ";
    }
    return result;
  }

  public boolean isFull(){
    //PRE: stack is not empty
    //POS: none
    //TAS: return whether or not the stack is full
    return top == MAX_CAP-1;
  }
}

public class CharStackTester{
  public static void main(String[] args){
    CharStack stack = new CharStack();

    //Test push and pop
    stack.push ('a'); //stack = a
    stack.push ('b'); //stack = ba
    stack.push ('c'); //stack = cba

    //Continue to test all other methods to make sure
    //they work as they should.
    System.out.println(stack.peek());
    System.out.println(stack.isEmpty());
    System.out.println(stack.toString());


  }
}
